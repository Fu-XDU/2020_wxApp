Page({
  data: {
    items:[{
      index:0,
      mainTitle:"情绪管理",
      subTitle:"压抑|沮丧|自卑",
      isSelected:true
    },
    {
      index:1,
      mainTitle:"人际关系",
      subTitle:"宿舍|家庭|学校",
      isSelected:false
    },
    {
      index:2,
      mainTitle:"恋爱情感",
      subTitle:"吵架|冷战|分手",
      isSelected:false
    },
    ]
  },
  // handle_selectChange:function(e){
  //   console.log(e.detail.currentIndex)
  // }
})
